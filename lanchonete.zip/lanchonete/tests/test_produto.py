import pytest
from fastapi.testclient import TestClient
from main import app

client = TestClient(app)


def test_integracao_fluxo_alterar_valor_produto():

    # Dados para criação
    codigo_teste = 555
    payload_criacao = {
        "codigo": codigo_teste,
        "valor": 10.0,
        "tipo": "Lanche",
        "desconto_percentual": 0
    }

    response_post = client.post("/produtos", json=payload_criacao)
    assert response_post.status_code == 200, "Falha ao criar produto para o teste"

    novo_valor = 15.50
    payload_alteracao = {"novo_valor": novo_valor}

    response_put = client.put(
        f"/produtos/{codigo_teste}/valor",
        json=payload_alteracao
    )

    assert response_put.status_code == 200
    assert response_put.json() == {"alterou": True}

    response_get = client.get(f"/produtos/{codigo_teste}")
    assert response_get.json()["valor"] == novo_valor


def test_alterar_valor_produto_inexistente():

    payload_alteracao = {"novo_valor": 20.0}
    response = client.put("/produtos/9999/valor", json=payload_alteracao)

    assert response.status_code == 404
    assert response.json()["detail"] == "Produto não encontrado"