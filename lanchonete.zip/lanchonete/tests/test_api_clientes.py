def test_post_e_get_cliente(client):
    r = client.post("/clientes", json={"cpf": "11122233344", "nome": "Cliente X"})
    assert r.status_code == 200
    assert r.json()["cpf"] == "11122233344"

    r2 = client.get("/clientes/11122233344")
    assert r2.status_code == 200
    assert r2.json()["nome"] == "Cliente X"