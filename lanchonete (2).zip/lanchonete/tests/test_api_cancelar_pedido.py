def test_deve_cancelar_pedido_com_sucesso(client):
    # criar cliente, produto e pedido via API ou fixtures
    client.post("/lanchonete/clientes", json={"cpf": "123456789"})
    client.post("/lanchonete/produtos", json={"codigo": 1, "nome": "X-Burger"})
    client.post("/lanchonete/pedidos", json={"cpf": "123456789", "produtos": [1]})

    response = client.post("/lanchonete/pedidos/1/cancelar")

    assert response.status_code == 200

    data = response.json()

    assert data["ok"] is True
    assert data["mensagem"] == "Pedido cancelado com sucesso"

    response = client.post("/lanchonete/pedidos/1/cancelar")

    assert response.status_code == 200

    data = response.json()

    def test_nao_deve_cancelar_pedido_inexistente(client):
        response = client.post("/lanchonete/pedidos/999/cancelar")

        assert response.status_code == 400

        data = response.json()

        assert data["detail"] == "Pedido não encontrado ou não pode ser cancelado"

    def test_nao_deve_cancelar_pedido_finalizado(client):
        client.post("/lanchonete/clientes", json={"cpf": "123456789"})
        client.post("/lanchonete/produtos", json={"codigo": 1, "nome": "X-Burger"})
        client.post("/lanchonete/pedidos", json={"cpf": "12345678900", "produtos": [1]})

        # finalizar pedido (ajuste conforme sua API)
        client.post("/lanchonete/pedidos/1/finalizar")

        response = client.post("/lanchonete/pedidos/1/cancelar")

        assert response.status_code == 400

    def test_deve_listar_pedidos_cancelados(client):
        client.post("/lanchonete/clientes", json={"cpf": "123456789"})
        client.post("/lanchonete/produtos", json={"codigo": 1, "nome": "X-Burger"})
        client.post("/lanchonete/pedidos", json={"cpf": "12345678900", "produtos": [1]})

        client.post("/lanchonete/pedidos/1/cancelar")

        response = client.get("/lanchonete/pedidos/cancelados")

        assert response.status_code == 200

        data = response.json()

        assert isinstance(data, list)
        assert len(data) > 0
        assert data[0]["esta_cancelado"] is True